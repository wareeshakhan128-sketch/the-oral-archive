from datetime import datetime
from app.extensions import db

class Story(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(140))
    body = db.Column(db.Text)
    category = db.Column(db.String(50))
    timestamp = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    
    # Metadata fields (JSON storage for simplicity in MySQL/SQLite)
    metadata_tags = db.Column(db.String(255), nullable=True) # Simple comma-separated tags
