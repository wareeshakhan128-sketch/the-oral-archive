import os

project_name = "research_platform"

files = {
    ".env": "SECRET_KEY=dev123\nDATABASE_URL=sqlite:///research.db",
    "requirements.txt": """Flask==3.0.0
Flask-SQLAlchemy==3.1.1
Flask-Migrate==4.0.5
Flask-Login==0.6.3
python-dotenv==1.0.0""",
    "run.py": """from app import create_app
app = create_app()
if __name__ == '__main__':
    app.run(debug=True)""",
    "config.py": """import os
from dotenv import load_dotenv
load_dotenv()
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-key'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///app.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False""",
    "app/__init__.py": """from flask import Flask
from config import Config
from app.extensions import db, migrate, login_manager
def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    from app.main import bp as main_bp
    app.register_blueprint(main_bp)
    from app.auth import bp as auth_bp
    app.register_blueprint(auth_bp, url_prefix='/auth')
    return app""",
    "app/extensions.py": """from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()""",
    "app/models.py": """from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db, login_manager
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True)
    email = db.Column(db.String(120), unique=True)
    password_hash = db.Column(db.String(256))
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150))
    status = db.Column(db.String(50))
@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))""",
    "app/main.py": """from flask import Blueprint, render_template
from app.models import Project
bp = Blueprint('main', __name__)
@bp.route('/')
def index():
    projects = Project.query.limit(5).all()
    return render_template('index.html', projects=projects)""",
    "app/auth.py": """from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, current_user, login_required
from app.extensions import db
from app.models import User
bp = Blueprint('auth', __name__)
@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and user.check_password(request.form['password']):
            login_user(user)
            return redirect(url_for('main.index'))
        flash('Invalid username or password')
    return render_template('auth/login.html')
@bp.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('main.index'))
@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        user = User(username=request.form['username'], email=request.form['email'])
        user.set_password(request.form['password'])
        db.session.add(user)
        db.session.commit()
        flash('Registered successfully!')
        return redirect(url_for('auth.login'))
    return render_template('auth/register.html')""",
}

templates = {
    "app/templates/base.html": """<!DOCTYPE html>
<html><head><title>{{ title }}</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2/dist/tailwind.min.css" rel="stylesheet">
</head><body class="bg-gray-100">
<nav class="bg-white shadow p-4">
    <div class="max-w-4xl mx-auto flex justify-between">
        <a href="/" class="text-2xl font-bold text-blue-600">ResearchHub</a>
        <div>
            {% if current_user.is_authenticated %}
                Hi {{ current_user.username }} | <a href="{{ url_for('auth.logout') }}" class="text-red-500">Logout</a>
            {% else %}
                <a href="{{ url_for('auth.login') }}" class="mr-4">Login</a>
                <a href="{{ url_for('auth.register') }}" class="bg-blue-500 text-white px-4 py-2 rounded">Register</a>
            {% endif %}
        </div>
    </div>
</nav>
<div class="max-w-4xl mx-auto py-8 px-4">
    {% with messages = get_flashed_messages() %}
        {% if messages %}
            {% for message in messages %}
                <div class="bg-green-100 border-l-4 border-green-500 p-4 mb-4">{{ message }}</div>
            {% endfor %}
        {% endif %}
    {% endwith %}
    {% block content %}{% endblock %}
</div></body></html>""",
    "app/templates/index.html": """{% extends "base.html" %}
{% block content %}
<div class="text-center py-12">
    <h1 class="text-5xl font-bold text-gray-900 mb-8">Research Collaboration Platform</h1>
    <p class="text-xl text-gray-600 mb-12">Discover research projects and collaborations</p>
</div>
<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
    {% for project in projects %}
    <div class="bg-white p-6 rounded-lg shadow">
        <h3 class="text-xl font-bold mb-2">{{ project.title }}</h3>
        <p class="text-blue-600 font-semibold">{{ project.status }}</p>
    </div>
    {% else %}
    <div class="col-span-full text-center py-12">
        <p>No projects yet. <a href="{{ url_for('auth.register') }}" class="text-blue-600">Register</a> to create one!</p>
    </div>
    {% endfor %}
</div>
{% endblock %}""",
    "app/templates/auth/login.html": """{% extends "base.html" %}
{% block content %}
<div class="max-w-md mx-auto">
    <h2 class="text-3xl font-bold text-center mb-8">Login</h2>
    <form method="POST" class="space-y-4">
        <input name="username" placeholder="Username" class="w-full p-3 border rounded" required>
        <input name="password" placeholder="Password" type="password" class="w-full p-3 border rounded" required>
        <button type="submit" class="w-full bg-blue-500 text-white py-3 rounded hover:bg-blue-600">Login</button>
    </form>
    <p class="text-center mt-4">No account? <a href="{{ url_for('auth.register') }}" class="text-blue-600">Register</a></p>
</div>
{% endblock %}""",
    "app/templates/auth/register.html": """{% extends "base.html" %}
{% block content %}
<div class="max-w-md mx-auto">
    <h2 class="text-3xl font-bold text-center mb-8">Register</h2>
    <form method="POST" class="space-y-4">
        <input name="username" placeholder="Username" class="w-full p-3 border rounded" required>
        <input name="email" type="email" placeholder="Email" class="w-full p-3 border rounded" required>
        <input name="password" type="password" placeholder="Password" class="w-full p-3 border rounded" required>
        <button type="submit" class="w-full bg-green-500 text-white py-3 rounded hover:bg-green-600">Register</button>
    </form>
</div>
{% endblock %}""",
}

def create_project():
    if os.path.exists(project_name):
        print(f"Delete {project_name} folder first!")
        return
    
    os.makedirs(project_name)
    print("Creating project...")
    
    all_files = {**files, **templates}
    for path, content in all_files.items():
        full_path = os.path.join(project_name, path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w') as f:
            f.write(content)
        print(f"Created: {path}")
    
    print("\n🎉 DONE! Run these EXACT commands:")
    print("cd research_platform")
    print("pip install -r requirements.txt")
    print("export FLASK_APP=run.py")
    print("flask db init")
    print("flask db migrate -m init")
    print("flask db upgrade") 
    print("flask run")
    print("Open: http://127.0.0.1:5000")

if __name__ == '__main__':
    create_project()
