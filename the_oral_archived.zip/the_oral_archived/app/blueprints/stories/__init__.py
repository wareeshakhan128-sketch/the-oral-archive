from flask import Blueprint

bp = Blueprint('stories', __name__)

from app.blueprints.stories import routes
