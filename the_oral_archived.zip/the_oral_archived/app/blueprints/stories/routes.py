from flask import render_template, flash, redirect, url_for, request
from flask_login import current_user, login_required
from app.extensions import db
from app.blueprints.stories import bp
from app.models.story import Story

@bp.route('/catalog')
def catalog():
    stories = Story.query.order_by(Story.timestamp.desc()).all()
    return render_template('stories/catalog.html', title='Story Catalog', stories=stories)

@bp.route('/submit', methods=['GET', 'POST'])
@login_required
def submit():
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        category = request.form['category']
        
        # Simple AI simulation: extract tags from body length
        ai_tags = "short-story" if len(body) < 500 else "long-read"
        
        story = Story(title=title, body=body, category=category, author=current_user, metadata_tags=ai_tags)
        db.session.add(story)
        db.session.commit()
        
        flash('Your story is now live!')
        return redirect(url_for('main.index'))
        
    return render_template('stories/submit.html', title='Submit Story')

@bp.route('/<int:id>')
def view(id):
    story = Story.query.get_or_404(id)
    return render_template('stories/view.html', title=story.title, story=story)
