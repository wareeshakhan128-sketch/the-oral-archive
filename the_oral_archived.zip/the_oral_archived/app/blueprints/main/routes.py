from flask import render_template
from app.blueprints.main import bp
from app.models.story import Story

@bp.route('/')
@bp.route('/index')
def index():
    recent_stories = Story.query.order_by(Story.timestamp.desc()).limit(5).all()
    return render_template('index.html', title='Home', stories=recent_stories)
